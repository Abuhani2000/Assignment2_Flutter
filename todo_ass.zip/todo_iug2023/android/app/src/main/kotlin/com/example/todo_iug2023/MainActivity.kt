package com.example.todo_iug2023

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
