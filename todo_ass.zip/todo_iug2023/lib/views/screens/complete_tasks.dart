import 'package:flutter/material.dart';
import 'package:todo_iug2023/data/data_source.dart';
import 'package:todo_iug2023/views/screens/all_tasks_screen.dart';
import 'package:todo_iug2023/views/screens/incomplete_tasks.dart';
import 'package:todo_iug2023/views/widgets/task_widget.dart';

class CompleteTasksScreen extends StatefulWidget {
  Function fun;

  CompleteTasksScreen(this.fun);

  @override
  State<CompleteTasksScreen> createState() => _CompleteTasksScreenState();
}

class _CompleteTasksScreenState extends State<CompleteTasksScreen> {
  updateWidget() {
    setState(() {});
  }

  @override
  Widget build(BuildContext context) {
    return MediaQuery.of(context).size.width > 400
        ? Row(
            mainAxisSize: MainAxisSize.min,
            children: [
              Container(
                width: MediaQuery.of(context).size.width * 0.4,
                child: Column(
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: [
                    ListTile(
                      onTap: () {
                        Navigator.push(
                          context,
                          MaterialPageRoute(
                            builder: (context) => AllTasksScreen(updateWidget),
                          ),
                        );
                      },
                      title: Text('All Tasks'),
                      trailing: Icon(Icons.arrow_forward_ios),
                    ),
                    ListTile(
                      onTap: () {
                        Navigator.push(
                          context,
                          MaterialPageRoute(
                            builder: (context) =>
                                CompleteTasksScreen(updateWidget),
                          ),
                        );
                      },
                      title: Text('Complete Tasks'),
                      trailing: Icon(Icons.arrow_forward_ios),
                    ),
                    ListTile(
                      onTap: () {
                        Navigator.push(
                          context,
                          MaterialPageRoute(
                            builder: (context) =>
                                InCompleteTasksScreen(updateWidget),
                          ),
                        );
                      },
                      title: Text('InComplete Tasks'),
                      trailing: Icon(Icons.arrow_forward_ios),
                    ),
                  ],
                ),
              ),
              Expanded(
                // width: MediaQuery.of(context).size.width * 0.8,
                child: ListView.builder(
                  itemCount: DataSource.tasks
                      .where((element) => element.isComplete)
                      .length,
                  itemBuilder: (context, index) {
                    return TaskWidget(
                        DataSource.tasks
                            .where((element) => element.isComplete)
                            .toList()[index],
                        widget.fun);
                  },
                ),
              ),
            ],
          )
        : ListView.builder(
            itemCount: DataSource.tasks.length,
            itemBuilder: (context, index) {
              return TaskWidget(DataSource.tasks[index], widget.fun);
            },
          );
    return ListView.builder(
      itemCount: DataSource.tasks.where((element) => element.isComplete).length,
      itemBuilder: (context, index) {
        return TaskWidget(
            DataSource.tasks
                .where((element) => element.isComplete)
                .toList()[index],
            widget.fun);
      },
    );
  }
}
