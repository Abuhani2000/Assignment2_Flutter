import 'dart:developer';

import 'package:flutter/material.dart';
import 'package:todo_iug2023/views/screens/all_tasks_screen.dart';
import 'package:todo_iug2023/views/screens/complete_tasks.dart';
import 'package:todo_iug2023/views/screens/incomplete_tasks.dart';

class MainTasksScreen extends StatefulWidget {
  const MainTasksScreen({super.key});

  @override
  State<MainTasksScreen> createState() => _MainTasksScreenState();
}

class _MainTasksScreenState extends State<MainTasksScreen> {
  PageController pageController = PageController();

  int pageIndex = 0;

  updateScreen() {
    log('set state from main screen has been excuted');
    setState(() {});
  }

  @override
  Widget build(BuildContext context) {
    // TODO: implement build
    return Scaffold(
      drawer: MediaQuery.of(context).size.width > 400
          ? null
          : Drawer(
              child: Column(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [

                  ListTile(
                    onTap: () {
                        pageController.jumpToPage(0);
                        updateScreen();
                        Navigator.pop(context);
                    },
                    title: Text('All Tasks'),
                    trailing: Icon(Icons.arrow_forward_ios),
                  ),
                  ListTile(
                    onTap: () {
                        pageController.jumpToPage(1);
                        updateScreen();
                        Navigator.pop(context);
                    },
                    title: Text('Complete Tasks'),
                    trailing: Icon(Icons.arrow_forward_ios),
                  ),
                  ListTile(
                    onTap: () {
                        pageController.jumpToPage(2);
                      updateScreen();
                      Navigator.pop(context);
                    },
                    title: Text('InComplete Tasks'),
                    trailing: Icon(Icons.arrow_forward_ios),
                  ),
                ],
              ),
            ),
      // bottomNavigationBar: BottomNavigationBar(
      //     currentIndex: pageIndex,
      //     onTap: (v) {
      //       pageIndex = v;
      //       pageController.jumpToPage(v);
      //       setState(() {});
      //     },
      //     items: const [
      //       BottomNavigationBarItem(icon: Icon(Icons.list), label: "All Tasks"),
      //       BottomNavigationBarItem(
      //           icon: Icon(Icons.done), label: "Complete Tasks"),
      //       BottomNavigationBarItem(
      //           icon: Icon(Icons.cancel), label: "InComplete Tasks"),
      //     ]),
      appBar: AppBar(
        title: Text("Todo App"),
        actions: [
          ElevatedButton(
              onPressed: () {
                updateScreen();
              },
              child: Text("Test SetState"))
        ],
      ),
      body: PageView(
        controller: pageController,
        children: [
          AllTasksScreen(updateScreen),
          CompleteTasksScreen(updateScreen),
          InCompleteTasksScreen(updateScreen)
        ],
      ),
    );
  }
}
