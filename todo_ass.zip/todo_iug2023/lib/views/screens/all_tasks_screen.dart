import 'package:flutter/material.dart';
import 'package:todo_iug2023/data/data_source.dart';
import 'package:todo_iug2023/views/screens/complete_tasks.dart';
import 'package:todo_iug2023/views/screens/incomplete_tasks.dart';
import 'package:todo_iug2023/views/widgets/task_widget.dart';

class AllTasksScreen extends StatefulWidget {
  Function fun;

  AllTasksScreen(this.fun);

  @override
  State<AllTasksScreen> createState() => _AllTasksScreenState();
}

class _AllTasksScreenState extends State<AllTasksScreen> {

  updateWidget(){
    setState((){});
  }

  @override
  Widget build(BuildContext context) {
    // TODO: implement build
    return MediaQuery.of(context).size.width > 400
        ? Row(
          mainAxisSize: MainAxisSize.min,
          children: [
            Container(
              width: MediaQuery.of(context).size.width * 0.4,
              child: Column(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  ListTile(
                    onTap: () {
                      print('click');
                      // Navigator.push(
                      //   context,
                      //   MaterialPageRoute(
                      //     builder: (context) =>
                      //         AllTasksScreen(updateWidget),
                      //   ),
                      // );
                    },
                    title: Text('All Tasks'),
                    trailing: Icon(Icons.arrow_forward_ios),
                  ),
                  ListTile(
                    onTap: () {
                      print('click');
                      // Navigator.push(
                      //   context,
                      //   MaterialPageRoute(
                      //     builder: (context) =>
                      //         CompleteTasksScreen(updateWidget),
                      //   ),
                      // );
                    },
                    title: Text('Complete Tasks'),
                    trailing: Icon(Icons.arrow_forward_ios),
                  ),
                  ListTile(
                    onTap: () {
                      print('click');
                      // Navigator.push(
                      //   context,
                      //   MaterialPageRoute(
                      //     builder: (context) =>
                      //         InCompleteTasksScreen(updateWidget),
                      //   ),
                      // );
                    },
                    title: Text('InComplete Tasks'),
                    trailing: Icon(Icons.arrow_forward_ios),
                  ),
                ],
              ),
            ),
            Expanded(
              // width: MediaQuery.of(context).size.width * 0.8,
              child: ListView.builder(
                itemCount: DataSource.tasks.length,
                itemBuilder: (context, index) {
                  return Container(
                    width: MediaQuery.of(context).size.width * 0.8,
                    child: TaskWidget(DataSource.tasks[index], widget.fun),
                  );
                },
              ),
            ),
          ],
        )
        : ListView.builder(
            itemCount: DataSource.tasks.length,
            itemBuilder: (context, index) {
              return TaskWidget(DataSource.tasks[index], widget.fun);
            },
          );
  }
}
