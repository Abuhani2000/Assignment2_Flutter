class Task {
  String name;
  bool isComplete;
  Task(this.name, [this.isComplete = false]);
}
