import 'package:todo_iug2023/modes/task.dart';

class DataSource {
  static List<Task> tasks = [
    Task("Go to unuversity",true),
     Task("Watching Tv"),
      Task("Having Breakfast", true),
       Task("Eating lauch"),
        Task("Praying Duhur", true),
         Task("Studying"),
  ];
}
